#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Twist Music Helper
DEV : Ali Abdelkhaliq

تنبيه:
- يعتمد السكربت على واجهات Twist الظاهرة في النسخة التي أرسلها المستخدم.
- لا توجد هنا معرفات باقات وهمية أو أسعار مفترضة؛ يتم جلب الباقات من الخادم.
- قد تتغير واجهات الخدمة أو شروطها، لذلك لا يمكن ضمان عملها دون اختبار بحسابك.
"""

import sys
import os
import re
import json
import time
import subprocess
import importlib.util
from datetime import datetime, timezone
from urllib.parse import urlparse
import webbrowser

# =========================
# إعدادات عامة
# =========================

BASE_URL = "https://api.twistmena.com/music"
APP_DOWNLOAD_URL = "https://play.google.com/store/apps/details?id=com.etisalat.music"
MONTHLY_LIMIT = 2000
HISTORY_PAGE_SIZE = 50
TIMEOUT = 25

# ملف تخزين تاريخ التجميع اليومي
COLLECT_LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".twist_collect_log.json")


def _load_collect_log():
    """قراءة سجل التجميع من الملف."""
    try:
        if os.path.exists(COLLECT_LOG_FILE):
            with open(COLLECT_LOG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_collect_log(log):
    """حفظ سجل التجميع في الملف."""
    try:
        with open(COLLECT_LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(log, f, ensure_ascii=False)
    except Exception:
        pass


def already_collected_today(phone):
    """
    True  → هذا الرقم جمع مهامه اليوم بالفعل.
    False → لم يجمع بعد أو كان آخر تجميع قبل اليوم.
    """
    today = datetime.now().strftime("%Y-%m-%d")
    log   = _load_collect_log()
    return log.get(str(phone)) == today


def mark_collected_today(phone):
    """تسجيل أن هذا الرقم جمع مهامه اليوم."""
    today = datetime.now().strftime("%Y-%m-%d")
    log   = _load_collect_log()
    log[str(phone)] = today
    _save_collect_log(log)

# تثبيت المكتبات الناقصة فقط
def install_dependencies():
    required = {"requests": "requests"}
    missing = [
        package for module, package in required.items()
        if importlib.util.find_spec(module) is None
    ]
    if not missing:
        return
    print("🔧 تثبيت المكتبات الناقصة:", ", ".join(missing))
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", *missing]
        )
    except Exception as exc:
        print("❌ تعذر تثبيت المكتبات:", exc)
        raise SystemExit(1)

install_dependencies()
import requests

# =========================
# ألوان الطرفية
# =========================

class C:
    R = "\033[0m"
    B = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    MAGENTA = "\033[95m"

def color(text, shade=C.R):
    return f"{shade}{text}{C.R}"

def pause():
    input("\nاضغط Enter للمتابعة...")

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    print(color("╔══════════════════════════════════════════════╗", C.CYAN))
    print(color("║              TWIST MUSIC HELPER              ║", C.MAGENTA + C.B))
    print(color("║                  DEV : Ali Abdelkhaliq                  ║", C.YELLOW + C.B))
    print(color("╚══════════════════════════════════════════════╝", C.CYAN))

# =========================
# أدوات مساعدة للبيانات
# =========================

def to_int(value, default=0):
    try:
        if isinstance(value, bool):
            return int(value)
        return int(float(str(value).replace(",", "").strip()))
    except (TypeError, ValueError):
        return default

def walk_dicts(value):
    """إرجاع كل القواميس الموجودة داخل JSON متداخل."""
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from walk_dicts(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk_dicts(item)

def first_value(data, keys, default=None):
    if not isinstance(data, dict):
        return default
    for key in keys:
        value = data.get(key)
        if value is not None:
            return value
    return default

def extract_units(text):
    """استخراج عدد الوحدات من وصف عربي أو إنجليزي."""
    if not text:
        return 0
    value = str(text).lower()
    patterns = [
        r"(\d+)\s*(?:وحد(?:ة|ه|ات)|unit(?:s)?)",
        r"(?:وحد(?:ة|ه|ات)|unit(?:s)?)\s*[:\-]?\s*(\d+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, value, re.IGNORECASE)
        if match:
            return to_int(match.group(1))
    return 0

def parse_datetime(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        stamp = float(value)
        if stamp > 10**12:
            stamp /= 1000
        try:
            return datetime.fromtimestamp(stamp, tz=timezone.utc)
        except (ValueError, OSError, OverflowError):
            return None
    raw = str(value).strip()
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None

# =========================
# واجهة Twist
# =========================

class TwistMusicAPI:
    def __init__(self):
        self.base_url = BASE_URL.rstrip("/")
        self.device_id = "AP3A.240905.015.A2"
        self.tg_device_id = self._uuid()
        self.session_id = self._uuid()
        self.token = None
        self.access_token = None
        self.tg_token = None
        self.refresh_token = None
        self.phone = None
        self.balance = 0
        self.session = requests.Session()

    @staticmethod
    def _uuid():
        import uuid
        return str(uuid.uuid4())

    def headers(self, extra=None):
        result = {
            "user-agent": "Twist-Mobile/11.2.9 (Android; 15; Mobile; music; ar-EG)",
            "app_version": "11.2.9",
            "appversion": "11.2.9",
            "channel": "mobileapp",
            "platform": "android",
            "accept": "application/json",
            "accept-language": "ar",
            "content-type": "application/json",
            "device_id": self.device_id,
            "tgdeviceid": self.tg_device_id,
            "sessionid": self.session_id,
            "host": "api.twistmena.com",
            "connection": "keep-alive",
        }
        if self.token:
            result["Authorization"] = f"Bearer {self.token}"
        if self.access_token:
            result["access-token"] = self.access_token
        if self.tg_token:
            result["tg-token"] = self.tg_token
        if self.refresh_token:
            result["tg-refresh-token"] = self.refresh_token
        if extra:
            result.update(extra)
        return result

    def request(self, method, path, **kwargs):
        url = path if path.startswith("http") else self.base_url + "/" + path.lstrip("/")
        kwargs.setdefault("headers", self.headers())
        kwargs.setdefault("timeout", TIMEOUT)
        return self.session.request(method, url, **kwargs)

    @staticmethod
    def format_phone(phone):
        phone = re.sub(r"[\s+\-()]", "", phone)
        if phone.startswith("0"):
            return "20" + phone[1:]
        if phone.startswith("20"):
            return phone
        return "20" + phone

    def send_otp(self, phone):
        formatted = self.format_phone(phone)
        try:
            response = self.request("POST", "/Dlogin/sendCode", json={"dial": formatted})
            if response.status_code == 200:
                self.phone = formatted
                return True, "تم إرسال رمز التحقق."
            return False, f"فشل إرسال الرمز: HTTP {response.status_code}"
        except requests.RequestException as exc:
            return False, f"مشكلة اتصال: {exc}"

    def verify_otp(self, code):
        if not self.phone:
            return False, "أرسل رقم الهاتف أولاً."
        payload = {
            "dial": self.phone,
            "verifyCode": code,
            "socialServiceName": "",
            "socialServiceToken": "",
        }
        try:
            response = self.request("POST", "/Dlogin/verify", json=payload)
            if response.status_code != 200:
                return False, f"فشل التحقق: HTTP {response.status_code}"
            data = response.json()
            self.token = first_value(data, ["token", "access_token"])
            self.access_token = first_value(data, ["accessToken"])
            self.tg_token = first_value(data, ["tgToken"])
            self.refresh_token = first_value(data, ["refreshToken"])
            if not any([self.token, self.access_token, self.tg_token]):
                return False, "لم يرجع الخادم رموز جلسة معروفة."
            return True, "تم تسجيل الدخول بنجاح."
        except (requests.RequestException, ValueError) as exc:
            return False, f"تعذر إكمال تسجيل الدخول: {exc}"

    def get_balance(self):
        try:
            response = self.request("GET", "/user/loyalty/balance/details")
            if response.status_code != 200:
                return None, f"HTTP {response.status_code}"
            data = response.json()
            balance = first_value(data, ["balance", "coins", "points"], None)
            if balance is None:
                for item in walk_dicts(data):
                    balance = first_value(item, ["balance", "coins", "points"], None)
                    if balance is not None:
                        break
            if balance is None:
                return None, "لم أتعرف على قيمة الرصيد في رد الخادم."
            self.balance = to_int(balance)
            return self.balance, None
        except (requests.RequestException, ValueError) as exc:
            return None, str(exc)

    def get_tasks(self):
        response = self.request("GET", "/user/loyalty/achievements/v2")
        if response.status_code != 200:
            raise RuntimeError(f"تعذر جلب المهام: HTTP {response.status_code}")
        data = response.json()
        tasks = []
        for category in data.get("badges", []) if isinstance(data, dict) else []:
            if not isinstance(category, dict):
                continue
            for task in category.get("badges", []) or []:
                if isinstance(task, dict):
                    tasks.append(task)
        return tasks

    def task_reward(self, task):
        reward = task.get("reward") or {}
        if isinstance(reward, dict):
            value = first_value(reward, ["points", "coins", "amount"], None)
            if value is not None:
                return to_int(value)
        return to_int(first_value(task, ["coins", "points", "rewardPoints"], 0))

    def collect_tasks(self):
        """تنفيذ المهام غير المكتملة مع إظهار نقاط كل مهمة."""
        try:
            tasks = self.get_tasks()
        except Exception as exc:
            return {"ok": False, "error": str(exc), "earned": 0, "success": 0, "failed": 0}

        earned = success_count = failed_count = 0
        print("\n" + color("نتيجة المهام:", C.CYAN + C.B))
        if not tasks:
            print("لم يرجع الخادم أي مهام.")
        for index, task in enumerate(tasks, 1):
            title = str(first_value(task, ["title", "name", "description"], f"مهمة {index}"))
            task_id = first_value(task, ["id", "actionId", "achievementId"])
            rewarded = bool(first_value(task, ["rewarded", "completed", "isCompleted"], False))
            reward = self.task_reward(task)

            if rewarded:
                print(color(f"↪ {title}: مكتملة مسبقاً (+{reward})", C.YELLOW))
                continue
            if not task_id:
                failed_count += 1
                print(color(f"✖ {title}: لا يوجد معرّف للمهمة", C.RED))
                continue

            try:
                response = self.request("POST", f"/loyalty/action/{task_id}")
                if response.status_code == 200:
                    success_count += 1
                    earned += reward
                    print(color(f"✔ {title} | +{reward} نقطة", C.GREEN))
                else:
                    failed_count += 1
                    print(color(f"✖ {title} | HTTP {response.status_code}", C.RED))
            except requests.RequestException as exc:
                failed_count += 1
                print(color(f"✖ {title} | {exc}", C.RED))

            time.sleep(0.25)

        return {
            "ok": True,
            "earned": earned,
            "success": success_count,
            "failed": failed_count,
        }

    def get_history(self):
        """قراءة سجل العمليات؛ يدعم أكثر من شكل شائع للصفحات."""
        all_items = []
        for page in range(1, 21):
            params = {"page": page, "limit": HISTORY_PAGE_SIZE}
            response = self.request("GET", "/user/loyalty/history", params=params)
            if response.status_code != 200:
                if page == 1:
                    raise RuntimeError(f"تعذر قراءة سجل العمليات: HTTP {response.status_code}")
                break
            data = response.json()
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = first_value(data, ["data", "history", "transactions", "items", "content"], [])
                if isinstance(items, dict):
                    items = first_value(items, ["items", "content", "data"], [])
            else:
                items = []
            if not isinstance(items, list) or not items:
                break
            all_items.extend(x for x in items if isinstance(x, dict))
            if len(items) < HISTORY_PAGE_SIZE:
                break
        return all_items

    def monthly_units_used(self):
        """حساب وحدات السحب هذا الشهر من أوصاف معاملات الخصم."""
        try:
            history = self.get_history()
        except Exception as exc:
            return None, f"تعذر قراءة سجل السحب: {exc}"

        now = datetime.now().astimezone()
        used = 0
        for item in history:
            description = str(first_value(item, ["description", "title", "name", "details"], ""))
            kind = str(first_value(item, ["type", "transactionType", "operation", "action"], "")).lower()
            status = str(first_value(item, ["status"], "")).lower()

            date_value = first_value(item, ["createdAt", "created_at", "date", "timestamp", "transactionDate"])
            transaction_date = parse_datetime(date_value)
            if transaction_date:
                local_date = transaction_date.astimezone()
                if (local_date.year, local_date.month) != (now.year, now.month):
                    continue

            is_debit = (
                "debit" in kind or "redeem" in kind or "withdraw" in kind
                or "خصم" in description or "استبدال" in description
                or "سحب" in description
            )
            if status and status not in ("success", "succeeded", "completed", "approved", "1"):
                continue
            if not is_debit:
                continue

            units = extract_units(description)
            if not units:
                units = to_int(first_value(item, ["units", "unitAmount", "amount"], 0))
            used += max(0, units)

        return used, None

    def get_packages(self):
        """جلب الباقات الحية من الخادم، دون استخدام معرفات افتراضية."""
        # جرّب أكثر من endpoint
        endpoints = [
            "/user/loyalty/packages",
            "/loyalty/packages",
            "/user/loyalty/redeem/packages",
        ]
        data = None
        last_status = None
        for ep in endpoints:
            try:
                response = self.request("GET", ep)
                last_status = response.status_code
                if response.status_code == 200:
                    data = response.json()
                    break
            except Exception:
                continue

        if data is None:
            raise RuntimeError(f"الخادم لم يعرض الباقات: HTTP {last_status}")

        # استخرج القائمة من أي شكل محتمل للـ response
        candidates = []
        if isinstance(data, list):
            candidates = data
        elif isinstance(data, dict):
            # جرّب كل المفاتيح الممكنة بعمق واحد وعمقين
            for key in ("packages", "data", "items", "offers", "results",
                        "redeemPackages", "loyaltyPackages", "content"):
                val = data.get(key)
                if isinstance(val, list) and val:
                    candidates = val
                    break
                if isinstance(val, dict):
                    for inner_key in ("packages", "items", "data", "content"):
                        inner = val.get(inner_key)
                        if isinstance(inner, list) and inner:
                            candidates = inner
                            break
                    if candidates:
                        break
            # لو لقينا dict فيه items مباشرة بدون wrapper
            if not candidates:
                for d in walk_dicts(data):
                    if isinstance(d.get("id"), (str, int)) and (
                        d.get("units") or d.get("unit") or d.get("quantity")
                    ):
                        candidates.append(d)

        if not isinstance(candidates, list):
            candidates = []

        packages = []
        seen = set()
        for item in candidates:
            if not isinstance(item, dict):
                continue
            package_id = first_value(item, ["id", "packageId", "productId",
                                            "offerId", "redeemId", "loyaltyPackageId"])
            units = first_value(item, ["units", "unit", "quantity",
                                       "amountUnits", "dataAmount", "value"])
            cost  = first_value(item, ["cost", "points", "coins", "price",
                                       "requiredPoints", "pointsRequired",
                                       "redeemPoints", "pointCost"])
            name  = first_value(item, ["name", "title", "description",
                                       "packageName", "displayName"], "باقة")
            if package_id is None:
                continue
            units = to_int(units, extract_units(str(name)))
            cost  = to_int(cost)
            if units <= 0 or cost <= 0:
                continue
            key = str(package_id)
            if key in seen:
                continue
            seen.add(key)
            packages.append({"id": key, "units": units, "cost": cost, "name": str(name)})

        return packages

    def redeem(self, package):
        """تنفيذ استبدال باقة واحدة بعد تأكيد المستخدم."""
        package_id = package["id"]
        paths = [
            f"/loyalty/redeem/{package_id}",
            f"/user/loyalty/redeem/{package_id}",
        ]
        last_status = None
        for path in paths:
            try:
                response = self.request("POST", path)
                last_status = response.status_code
                if response.status_code == 200:
                    return True, "تم إرسال طلب الاستبدال بنجاح."
                # لا نجرب مساراً بديلاً عند خطأ مصادقة/حظر.
                if response.status_code in (401, 403):
                    break
            except requests.RequestException as exc:
                return False, str(exc)
        return False, f"فشل الاستبدال. HTTP {last_status}"

# =========================
# تسجيل الدخول والتقارير
# =========================

def login(api):
    print(color("\nتسجيل الدخول برقم الهاتف", C.CYAN + C.B))
    phone = input("رقم الهاتف: ").strip()
    if not phone:
        print(color("لم يتم إدخال رقم.", C.RED))
        return False

    ok, message = api.send_otp(phone)
    print(message)
    if not ok:
        return False

    code = input("أدخل رمز OTP الذي وصلك: ").strip()
    if not re.fullmatch(r"\d{4,8}", code):
        print(color("رمز التحقق غير صالح من حيث التنسيق.", C.RED))
        return False

    ok, message = api.verify_otp(code)
    print(message)
    return ok

def show_monthly_report(api):
    used, error = api.monthly_units_used()
    if error:
        print(color(error, C.YELLOW))
        print(f"الحد الشهري: {MONTHLY_LIMIT} وحدة")
        return None
    remaining = max(0, MONTHLY_LIMIT - used)
    print(f"📦 المسحوب هذا الشهر: {used} وحدة")
    print(f"🎯 الحد الشهري: {MONTHLY_LIMIT} وحدة")
    print(f"🟢 المتبقي هذا الشهر: {remaining} وحدة")
    return remaining

def show_balance(api):
    balance, error = api.get_balance()
    if error:
        print(color(f"تعذر جلب الرصيد: {error}", C.RED))
        return None
    print(color(f"💰 رصيدك الحالي: {balance} نقطة", C.GREEN + C.B))
    return balance

def collect_and_redeem(api):
    # ── حماية التجميع اليومي ──────────────────────────────────────────────
    if already_collected_today(api.phone):
        from datetime import timedelta
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        print()
        print(color("╔══════════════════════════════════════════════╗", C.YELLOW))
        print(color("║   ⚠️  لقد تم جمع المهام مسبقاً اليوم        ║", C.YELLOW + C.B))
        print(color(f"║   📅  حاول غداً: {tomorrow}                 ║", C.CYAN))
        print(color("╚══════════════════════════════════════════════╝", C.YELLOW))

        # عرض الرصيد الحالي والباقات المتاحة للسحب
        print()
        current_balance = show_balance(api)
        if current_balance is None:
            return

        remaining = show_monthly_report(api)
        if remaining is None or remaining <= 0:
            if remaining is not None and remaining <= 0:
                print(color("\nوصلت إلى الحد الشهري للسحب.", C.YELLOW))
            return

        try:
            packages = api.get_packages()
        except Exception as exc:
            print(color(f"\nتعذر جلب الباقات: {exc}", C.RED))
            return

        if not packages:
            print(color("\n⚠️  الخادم لم يُرجع أي باقات قابلة للتحليل.", C.YELLOW))
            return

        affordable = [
            p for p in packages
            if p["cost"] <= current_balance and p["units"] <= remaining
        ]
        if not affordable:
            cheapest = min(packages, key=lambda p: p["cost"])
            print(color(
                f"\n⚠️  لا توجد باقة تناسب رصيدك حالياً.\n"
                f"   أرخص باقة: {cheapest['name']} | {cheapest['units']} وحدة | {cheapest['cost']} نقطة",
                C.YELLOW
            ))
            return

        affordable.sort(key=lambda p: (p["units"], -p["cost"]), reverse=True)
        print("\n" + color("الباقات المتاحة للسحب الآن:", C.CYAN + C.B))
        for index, pkg in enumerate(affordable, 1):
            print(f"{index}. {pkg['name']} | {pkg['units']} وحدة | {pkg['cost']} نقطة")
        print("0. إلغاء")

        choice = input("\nاختر الباقة للسحب: ").strip()
        if choice == "0" or not choice.isdigit() or not (1 <= int(choice) <= len(affordable)):
            print("تم الإلغاء." if choice == "0" else color("اختيار غير صحيح.", C.RED))
            return

        selected = affordable[int(choice) - 1]
        print(f"\nالباقة: {selected['name']} | {selected['units']} وحدة | {selected['cost']} نقطة")
        confirm = input("اكتب YES للتأكيد: ").strip()
        if confirm != "YES":
            print("تم إلغاء الاستبدال.")
            return

        ok, message = api.redeem(selected)
        print(color(message, C.GREEN if ok else C.RED))
        if ok:
            new_balance, _ = api.get_balance()
            print(f"الرصيد بعد السحب: {new_balance if new_balance is not None else 'غير متاح'}")
        return
    # ─────────────────────────────────────────────────────────────────────

    previous_balance, error = api.get_balance()
    if error:
        print(color(f"تعذر قراءة الرصيد قبل التجميع: {error}", C.RED))
        return
    print(f"\nالرصيد قبل التجميع: {previous_balance} نقطة")

    result = api.collect_tasks()
    if not result["ok"]:
        print(color(result["error"], C.RED))
        return

    # ── تسجيل التجميع بعد نجاحه فعلاً ───────────────────────────────────
    if result["success"] > 0:
        mark_collected_today(api.phone)
    # ─────────────────────────────────────────────────────────────────────

    # انتظر تحديث الرصيد من السيرفر (قد يتأخر بعد التجميع)
    current_balance = None
    balance_error   = None
    for _attempt in range(4):
        time.sleep(2)
        current_balance, balance_error = api.get_balance()
        if current_balance is not None and current_balance != previous_balance:
            break  # تحدّث فعلاً

    if balance_error or current_balance is None:
        print(color("تم تنفيذ طلبات المهام، لكن تعذر تحديث الرصيد.", C.YELLOW))
        current_balance = previous_balance + result["earned"]
    elif current_balance == previous_balance and result["earned"] > 0:
        # السيرفر لم يعكس النقاط بعد — نحسبها يدوياً
        print(color("⚠️  السيرفر لم يعكس النقاط فوراً — تم حسابها تقديرياً.", C.YELLOW))
        current_balance = previous_balance + result["earned"]

    print("\n" + color("ملخص التجميع", C.CYAN + C.B))
    print(f"المهام الناجحة: {result['success']}")
    print(f"المهام الفاشلة: {result['failed']}")
    print(f"النقاط المكتسبة حسب ردود المهام: {result['earned']}")
    print(f"الرصيد السابق: {previous_balance}")
    print(f"الرصيد الحالي: {current_balance}")
    print(f"فرق الرصيد الفعلي: {current_balance - previous_balance}")

    remaining = show_monthly_report(api)
    if remaining is None:
        print(color("\nلن أنفذ السحب تلقائياً لأن سجل السحب الشهري لم يُقرأ بشكل موثوق.", C.YELLOW))
        return
    if remaining <= 0:
        print(color("\nوصلت إلى الحد الشهري؛ لن يتم تنفيذ سحب إضافي.", C.YELLOW))
        return

    try:
        packages = api.get_packages()
    except Exception as exc:
        print(color(f"\nتعذر جلب الباقات: {exc}", C.RED))
        return

    if not packages:
        print(color("\n⚠️  الخادم لم يُرجع أي باقات قابلة للتحليل.", C.YELLOW))
        print("قد يكون الموقع قد غيّر شكل الـ response — راجع Kemo.")
        return

    # تشخيص واضح لكل باقة لماذا تم استبعادها
    affordable = []
    blocked_balance = 0
    blocked_limit   = 0
    for p in packages:
        fits_balance = p["cost"]  <= current_balance
        fits_limit   = p["units"] <= remaining
        if fits_balance and fits_limit:
            affordable.append(p)
        elif not fits_balance:
            blocked_balance += 1
        else:
            blocked_limit += 1

    if not affordable:
        print(color("\n⚠️  لا توجد باقة متاحة حالياً:", C.YELLOW))
        if blocked_balance:
            print(color(
                f"   • {blocked_balance} باقة تكلّف أكثر من رصيدك ({current_balance} نقطة)", C.YELLOW
            ))
        if blocked_limit:
            print(color(
                f"   • {blocked_limit} باقة تتجاوز المتبقي من الحد الشهري ({remaining} وحدة)", C.YELLOW
            ))
        # اعرض أرخص باقة موجودة كمرجع
        cheapest = min(packages, key=lambda p: p["cost"])
        print(color(
            f"\n   أرخص باقة موجودة: {cheapest['name']} | "
            f"{cheapest['units']} وحدة | {cheapest['cost']} نقطة",
            C.CYAN
        ))
        return

    affordable.sort(key=lambda p: (p["units"], -p["cost"]), reverse=True)
    print("\n" + color("الباقات المتاحة حسب الرصيد والحد الشهري:", C.CYAN + C.B))
    for index, pkg in enumerate(affordable, 1):
        print(f"{index}. {pkg['name']} | {pkg['units']} وحدة | {pkg['cost']} نقطة")
    print("0. إلغاء السحب")

    choice = input("\nاختر الباقة: ").strip()
    if choice == "0":
        print("تم تخطي السحب.")
        return
    if not choice.isdigit() or not (1 <= int(choice) <= len(affordable)):
        print(color("اختيار غير صحيح.", C.RED))
        return

    selected = affordable[int(choice) - 1]
    print("\nراجع العملية قبل تنفيذها:")
    print(f"الباقة: {selected['name']}")
    print(f"الوحدات: {selected['units']}")
    print(f"التكلفة: {selected['cost']} نقطة")
    confirm = input("اكتب YES للتأكيد: ").strip()
    if confirm != "YES":
        print("تم إلغاء الاستبدال.")
        return

    ok, message = api.redeem(selected)
    print(message)
    if ok:
        new_balance, _ = api.get_balance()
        print(f"الرصيد بعد السحب: {new_balance if new_balance is not None else 'غير متاح'}")
        used_after, err_after = api.monthly_units_used()
        if not err_after:
            print(f"المسحوب هذا الشهر بعد العملية: {used_after} وحدة")
            print(f"المتبقي: {max(0, MONTHLY_LIMIT - used_after)} وحدة")

def open_app():
    print("جاري فتح صفحة تطبيق Twist Music على Google Play...")
    try:
        opened = webbrowser.open(APP_DOWNLOAD_URL)
        if not opened:
            print("لو لم تفتح الصفحة تلقائياً، استخدم الرابط التالي:")
            print(APP_DOWNLOAD_URL)
    except Exception:
        print(APP_DOWNLOAD_URL)

def main():
    # القائمة الرئيسية تظهر أولاً؛ تسجيل الدخول مطلوب فقط للوظائف المرتبطة بالحساب.
    api = TwistMusicAPI()
    logged_in = False

    while True:
        clear()
        banner()
        print(color("\n╭────────────────────────────────────────────╮", C.CYAN))
        print(color("│  1) ", C.YELLOW + C.B) + color("عرض رصيد الكوينز", C.GREEN))
        print(color("│  2) ", C.YELLOW + C.B) + color("تجميع النقاط + السحب في عملية واحدة", C.GREEN))
        print(color("│  3) ", C.YELLOW + C.B) + color("تحميل تطبيق Twist Music", C.BLUE))
        print(color("│  0) ", C.YELLOW + C.B) + color("خروج", C.RED))
        print(color("╰────────────────────────────────────────────╯", C.CYAN))

        choice = input(color("\nاختيارك: ", C.MAGENTA + C.B)).strip()

        if choice in ("1", "2") and not logged_in:
            clear()
            banner()
            if not login(api):
                print(color("\nتعذر تسجيل الدخول. ارجع للقائمة وحاول مرة أخرى.", C.RED))
                pause()
                continue
            logged_in = True

        if choice == "1":
            clear()
            banner()
            show_balance(api)
            show_monthly_report(api)
            pause()
        elif choice == "2":
            clear()
            banner()
            collect_and_redeem(api)
            pause()
        elif choice == "3":
            open_app()
            pause()
        elif choice == "0":
            print("إلى اللقاء 👋")
            break
        elif choice not in ("1", "2", "3"):
            print(color("اختيار غير صحيح.", C.RED))
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nتم الإيقاف.")
    except Exception as exc:
        print(color(f"\nحدث خطأ غير متوقع: {exc}", C.RED))
