# -*- coding: utf-8 -*-
"""Twist Music Helper - Android UI | Developer: Ali Abdelkhaliq"""
import threading
import io
import contextlib

from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup

from twist_core import TwistMusicAPI, already_collected_today, mark_collected_today, MONTHLY_LIMIT

KV = r'''
<MainUI>:
    orientation: 'vertical'
    padding: dp(14)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: (0.035, 0.055, 0.10, 1)
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: '[b]TWIST MUSIC HELPER[/b]\n[color=ffd166]المطور علي عبدالخالق[/color]'
        markup: True
        font_size: '22sp'
        size_hint_y: None
        height: dp(76)
        halign: 'center'
        valign: 'middle'
    TextInput:
        id: phone
        hint_text: 'رقم الهاتف'
        multiline: False
        input_filter: 'int'
        size_hint_y: None
        height: dp(48)
        padding: dp(12)
    Button:
        text: 'إرسال رمز التحقق'
        size_hint_y: None
        height: dp(48)
        on_release: root.send_code()
    TextInput:
        id: otp
        hint_text: 'رمز OTP'
        multiline: False
        input_filter: 'int'
        size_hint_y: None
        height: dp(48)
        padding: dp(12)
    Button:
        text: 'تأكيد تسجيل الدخول'
        size_hint_y: None
        height: dp(48)
        on_release: root.verify_code()
    GridLayout:
        cols: 2
        spacing: dp(8)
        size_hint_y: None
        height: dp(104)
        Button:
            text: 'عرض الرصيد'
            on_release: root.show_balance()
        Button:
            text: 'تجميع النقاط'
            on_release: root.collect()
    Button:
        text: 'عرض الباقات المتاحة'
        size_hint_y: None
        height: dp(48)
        on_release: root.load_packages()
    ScrollView:
        do_scroll_x: False
        Label:
            id: output
            text: 'سجّل الدخول برقم هاتفك للبدء.\n\nاستخدم التطبيق وفق شروط خدمة Twist.'
            markup: True
            size_hint_y: None
            height: self.texture_size[1] + dp(24)
            text_size: self.width - dp(12), None
            halign: 'right'
            valign: 'top'
            padding: dp(8), dp(8)
    Label:
        text: 'Twist Music Helper • Ali Abdelkhaliq'
        font_size: '11sp'
        size_hint_y: None
        height: dp(24)
        color: (0.65, 0.7, 0.8, 1)
'''

class MainUI(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.api = TwistMusicAPI()
        self.logged_in = False
        self.packages = []

    def log(self, message):
        self.ids.output.text = str(message)

    def run_bg(self, fn, success_text='تمت العملية'):
        self.log('جارٍ تنفيذ العملية، يرجى الانتظار...')
        def worker():
            try:
                result = fn()
                text = success_text if result is None else str(result)
            except Exception as exc:
                text = f'حدث خطأ: {exc}'
            Clock.schedule_once(lambda _dt: self.log(text), 0)
        threading.Thread(target=worker, daemon=True).start()

    def send_code(self):
        phone = self.ids.phone.text.strip()
        if not phone:
            self.log('من فضلك أدخل رقم الهاتف.')
            return
        def action():
            ok, msg = self.api.send_otp(phone)
            return msg if ok else 'تعذر الإرسال: ' + msg
        self.run_bg(action)

    def verify_code(self):
        code = self.ids.otp.text.strip()
        if not code:
            self.log('أدخل رمز التحقق الذي وصلك.')
            return
        def action():
            ok, msg = self.api.verify_otp(code)
            if ok:
                self.logged_in = True
                return 'تم تسجيل الدخول بنجاح. يمكنك الآن عرض الرصيد وتجميع النقاط.'
            return msg
        self.run_bg(action)

    def require_login(self):
        if not self.logged_in:
            self.log('يجب تسجيل الدخول أولاً.')
            return False
        return True

    def show_balance(self):
        if not self.require_login(): return
        def action():
            balance, error = self.api.get_balance()
            if error: return 'تعذر جلب الرصيد: ' + str(error)
            used, err = self.api.monthly_units_used()
            if err: return f'الرصيد الحالي: {balance} نقطة\nتعذر قراءة السحب الشهري: {err}'
            return f'الرصيد الحالي: {balance} نقطة\nالمسحوب هذا الشهر: {used} وحدة\nالمتبقي من الحد الشهري: {max(0, MONTHLY_LIMIT-used)} وحدة'
        self.run_bg(action)

    def collect(self):
        if not self.require_login(): return
        def action():
            if already_collected_today(self.api.phone):
                return 'تم تسجيل تجميع المهام لهذا الرقم اليوم. حاول في اليوم التالي.'
            before, err = self.api.get_balance()
            if err: return 'تعذر قراءة الرصيد قبل التجميع: ' + str(err)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                result = self.api.collect_tasks()
            if not result.get('ok'):
                return result.get('error', 'تعذر تنفيذ المهام')
            if result.get('success', 0) > 0:
                mark_collected_today(self.api.phone)
            after, balance_error = self.api.get_balance()
            if balance_error or after is None: after = before + result.get('earned', 0)
            used, used_error = self.api.monthly_units_used()
            report = (f"تم تنفيذ التجميع.\nالمهام الناجحة: {result.get('success',0)}\n"
                      f"المهام الفاشلة: {result.get('failed',0)}\nالنقاط المكتسبة: {result.get('earned',0)}\n"
                      f"الرصيد قبل التجميع: {before}\nالرصيد الحالي: {after}")
            if not used_error:
                report += f"\nالمسحوب هذا الشهر: {used} وحدة\nالمتبقي: {max(0, MONTHLY_LIMIT-used)} وحدة"
            return report
        self.run_bg(action)

    def load_packages(self):
        if not self.require_login(): return
        def action():
            self.packages = self.api.get_packages()
            if not self.packages: return 'لا توجد باقات متاحة حالياً.'
            lines = ['الباقات المتاحة:']
            for i, p in enumerate(self.packages, 1):
                lines.append(f"{i}) {p['name']} — {p['units']} وحدة — {p['cost']} نقطة")
            lines.append('\nلاستبدال باقة، تواصل مع دعم Twist أو استخدم التطبيق الرسمي.')
            return '\n'.join(lines)
        self.run_bg(action)

class TwistAliApp(App):
    title = 'Twist Music Helper'
    def build(self):
        Builder.load_string(KV)
        return MainUI()

if __name__ == '__main__':
    TwistAliApp().run()
